import { LightningElement, track } from 'lwc';
import getWeatherData from '@salesforce/apex/AccountWeatherController.getWeatherData';
import cloud_temp from '@salesforce/resourceUrl/cloud_temp';

export default class ShowTodayWeather extends LightningElement {
    @track cityName;
    @track weatherObj = { 'sobjectType': 'AccountWeatherController.WeatherReport' }; 
    @track showData = false;
    @track showSpinner = false;

    cloudTempImage = cloud_temp;
    updateCity(event){
        this.cityName = event.target.value;

        
    }

    showWeatherData(event){
        this.showSpinner = true;
        //debugger;
        console.log("cityname : "+this.cityName);

        getWeatherData({cityName : this.cityName}).then((resp)=>{
            
            console.log("resp : ....");
            console.log(resp);
            if(resp){
                this.weatherObj = resp;
                this.showData = true;
            }else{
                console.log('having some problem..');
                this.showData = false;
            }
            this.showSpinner = false;

        }).catch((err) => {
        // Handle any error that occurred in any of the previous
        // promises in the chain.
            console.log("error is coming.");
            console.log(err);
        console.log(JSON.stringify(err));
        this.showSpinner = false;
        });
    }
}