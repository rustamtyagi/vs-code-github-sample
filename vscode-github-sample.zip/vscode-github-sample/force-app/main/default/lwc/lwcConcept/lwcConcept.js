import { LightningElement, track } from 'lwc';

export default class LwcConcept extends LightningElement {
    @track
    inputValue;
    
    checkValue(){
        console.log("inputValue :: "+this.inputValue);

    }
}