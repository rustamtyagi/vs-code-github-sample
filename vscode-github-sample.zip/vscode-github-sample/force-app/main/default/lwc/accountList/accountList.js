import { LightningElement, wire, track } from 'lwc';
import getAccList from '@salesforce/apex/AccountController.getAccList';
import { updateRecord } from 'lightning/uiRecordApi';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import FIRSTNAME_FIELD from '@salesforce/schema/Account.Name';
import LASTNAME_FIELD from '@salesforce/schema/Account.AccountNumber';
import ID_FIELD from '@salesforce/schema/Account.Id';

import {
    CurrentPageReference
} from 'lightning/navigation';
import {
    registerListener,
    unregisterAllListeners,
    fireEvent
} from 'c/pubsub';

let accIds = [];
const cols = [
    { label: 'Name', fieldName: 'Name', editable: true },
    { label: 'Account Number', fieldName: 'AccountNumber', editable: true },
    { label: 'Phone', fieldName: 'Phone', type: 'phone' }
];
export default class DatatableUpdateExample extends LightningElement {

    @track error;
    @track columns = cols;
    @track draftValues = [];

    @wire(getAccList)
    accList;

    @wire(CurrentPageReference) pageRef;
 
    @track accIds = [];
    @track selectionError = false;

      connectedCallback() {
          // subscribe to inputChangeEvent event
          registerListener('inputChangeEvent', this.handleChange2, this);
      }
 
      disconnectedCallback() {
          // unsubscribe from inputChangeEvent event
          unregisterAllListeners(this);
      }
 
      handleChange2(inpVal) {
        console.log("event handler inpVal: ....");
        console.log(inpVal);
        var accListTemp = [];
        accListTemp.push(inpVal);

        console.log(accListTemp);
        console.log(this.accList.data);

        console.log("accList length : "+this.accList.data.length);

        for(var i=0;i<this.accList.data.length;i++){
            accListTemp.push(this.accList.data[i]);
        }
        this.accList.data = accListTemp;

        console.log("updated accList :::: ");
        console.log(accListTemp);
        console.log(this.accList.data);
        //refreshApex(this.accList);
      }

    handleSave(event) {
        const recordInputs =  event.detail.draftValues.slice().map(draft => {
            const fields = Object.assign({}, draft);
            return { fields };
        });
    
        const promises = recordInputs.map(recordInput => updateRecord(recordInput));
        Promise.all(promises).then(accounts => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Accounts updated',
                    variant: 'success'
                })
            );
             // Clear all draft values
             this.draftValues = [];
    
             // Display fresh data in the datatable
             return refreshApex(this.accList);
        }).catch(error => { // Handle error 
        });
    }
    getSelectedRecord(event){
        const selectedRows = event.detail.selectedRows;
        this.accIds = [];
        if(selectedRows.length > 0){
            // Display that fieldName of the selected rows
            for (let i = 0; i < selectedRows.length; i++){
                console.log("You selected Name: " + selectedRows[i].Name);
                console.log("You selected Phone: " + selectedRows[i].Phone);
                console.log("You selected AccountNumber: " + selectedRows[i].AccountNumber);
                console.log("You selected id: " + selectedRows[i].Id);
                this.accIds.push(selectedRows[i].Id);
            }
        }
        console.log("accIds list length : "+this.accIds.length);
    }
    createChildRecords(event){
        //debugger;
        console.log("createChildRecords accIds list length : "+this.accIds.length);
        if(this.accIds.length > 0){
            console.log("create records..");
            console.log(this.accIds);
            this.selectionError = false;
        }else{
            this.selectionError = true;
            console.log("select atleast one record.");
        }
    }
}