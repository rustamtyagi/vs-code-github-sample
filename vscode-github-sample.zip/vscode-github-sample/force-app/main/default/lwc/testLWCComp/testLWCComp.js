import { LightningElement, track } from 'lwc';

export default class TestLWCComp extends LightningElement {
    @track
    status = "Completed";
}