import { LightningElement, api, track } from 'lwc';
import currUserId from '@salesforce/user/Id';
import createOppObj from "@salesforce/apex/LWCConceptsController.createOppObj";

export default class CreateOpp extends LightningElement {
    userId = currUserId;
    @api recordId;
    @api objectApiName;

    @track oppCreationMsg = '';

    createOpp(event){
        console.log("create opp.");
        createOppObj({accId : this.recordId}).then((resp)=>{
            console.log("response : ....");
            console.log(resp);
            
            console.log("resp.msg :: "+resp.msg);
            //console.log(resp.opp);
            this.oppCreationMsg = resp.msg;
            


        }).catch((err) => {
        // Handle any error that occurred in any of the previous
        // promises in the chain.

        console.log(JSON.stringify(err));
        });

    }
}