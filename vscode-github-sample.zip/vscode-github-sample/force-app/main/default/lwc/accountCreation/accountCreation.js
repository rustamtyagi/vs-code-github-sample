import { LightningElement, wire, track } from 'lwc';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import NAME_FIELD from '@salesforce/schema/Account.Name';
import WEBSITE_FIELD from '@salesforce/schema/Account.Website';

import { CurrentPageReference } from 'lightning/navigation';
import { fireEvent } from 'c/pubsub';

import createAccObj from "@salesforce/apex/AccountController.createAccObj";
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
/**
 * Creates Account records.
 */
export default class AccountCreator extends LightningElement {

    @wire(CurrentPageReference) pageRef;

    accountObject = ACCOUNT_OBJECT;
    myFields = [NAME_FIELD, WEBSITE_FIELD];

    
    @track
    accObj = { 'sobjectType': 'Account' }; 

    updateAccObj(event){
        this.accObj = {...this.accObj , [event.target.dataset.field] : event.detail.value};
        
        
    
    }

    createAccount(component, event){
        console.log("create acc obj...");
        console.log(this.accObj);
        console.log("name : "+this.accObj.Name);
        console.log("number : "+this.accObj.AccountNumber);
        
        createAccObj({accObj : this.accObj}).then((resp)=>{
            console.log("response : ....");
            console.log(resp);

            const evt = new ShowToastEvent({
                title: "Success",
                message: "Account Creaetd successfully",
                variant: "success",
            });
            this.dispatchEvent(evt);


            fireEvent(this.pageRef, 'inputChangeEvent', resp);
            this.accObj = {};

        }).catch((err) => {
        // Handle any error that occurred in any of the previous
        // promises in the chain.

        console.log(JSON.stringify(err));
        });

        

    }

    handleAccountCreated(event){
        fireEvent(this.pageRef, 'inputChangeEvent', "account is created");
        // Run code when account is created.
        console.log("event.detail.id : "+event.detail.id);

        
        console.log(event.detail);
        
        console.log("1111 record creted...");
        //console.log(event.detail.record);
        console.log(event.detail.apiName);
        console.log(event.detail.fields);
        

    }
}